from mypackage import myModule
