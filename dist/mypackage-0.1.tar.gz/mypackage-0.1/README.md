# mypackage

## Documentation
This is an example and a test excercise.
